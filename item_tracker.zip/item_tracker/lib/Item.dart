class Item{
  String name;
  int count;

  Item(this.name, this.count);
}